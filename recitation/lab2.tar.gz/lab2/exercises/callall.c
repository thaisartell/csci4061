#include <sys/types.h>
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>


int main(int argc, char *argv[]) {

    pid_t pid = fork();
    if(pid == 0) { // Use execl for fanout.o with argument 5
        
    }
    wait(NULL);

    pid = fork();
    if(pid == 0) { // Use execv for traverse.o with argument nestdir
        
    }
    wait(NULL);

    return 0;

}