#include <stdio.h>

int main(int argc, char *argv[]) {
    printf("Welcome to CSCI 4061!!!\n");
    return 0;
}