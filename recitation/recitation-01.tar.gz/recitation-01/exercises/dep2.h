#ifndef DEP2_H_
#define DEP2_H_

int pdtres(int *a, int *b, int n);

#endif