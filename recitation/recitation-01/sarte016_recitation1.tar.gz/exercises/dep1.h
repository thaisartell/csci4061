#ifndef DEP1_H_
#define DEP1_H_

int sumres(int *a, int *b, int n);

#endif