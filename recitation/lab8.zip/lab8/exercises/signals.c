#include <signal.h>
#include <stdio.h>
#include <unistd.h>

int loop = 0;

void ctrlHandler(int signo) {

}

int main(int argc, char *argv[]) {
    struct sigaction action;
    int counter = 0;

    // install ctrlHandler
    // block sigint

    while(!loop) {
        printf("Counter: %d\n", counter++);
        fflush(stdout);

        // check value of counter and unblock signint

        sleep(1);
    }

    printf("Graceful exit\n");
    fflush(stdout);

    return 0;
}

/*
Expected output: '//' says what happens and is not printed by the code

// SIGINT blocked
Counter: 0
Counter: 1
^CCounter: 2 // Ctrl+C
Counter: 3
Counter: 4
Loop var set // SIGINT enabled
Graceful exit

*/