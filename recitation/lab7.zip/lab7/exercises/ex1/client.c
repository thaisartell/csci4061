#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define STRSZ 100
#define PORT 3000

/****************************/
// IMPORTANT: ERROR CHECK ALL SOCKET APIs
/****************************/

int main(int argc, char *argv[]) {
    // create TCP socket
    int sockfd;

    // create sockaddr with server information
    struct sockaddr_in servaddr;

    // connect to server using sockfd
    

    char msg[STRSZ] = "";
    while(1){
        fprintf(stdout, "Client: ");
        fscanf(stdin, "%[^\n]s", msg); // read input with space until a newline
        setbuf(stdin, NULL); // clear stdin buffer
        
        // send message to server

        // if message is END break out

        // Receive message from server

        fprintf(stdout, "Server: %s\n", msg);
    }

    // close sockfd

    fprintf(stdout, "Client exiting...\n");

    return 0;
}