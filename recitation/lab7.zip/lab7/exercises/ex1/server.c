#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

#define BACKLOG 5 // connection request queue of 5
#define STRSZ 100
#define PORT 3000 

/****************************/
// IMPORTANT: ERROR CHECK ALL SOCKET APIs
/****************************/
int main(int argc, char *argv[]) {
    // create listening TCP socket
    int listen_fd;

    // create sockaddr_in for server with listening port and address informatin
    struct sockaddr_in servaddr;

    // bind the listen_fd to servaddr

    // set the listening queue for server

    // accept connection request from client and create new socket

    char msg[STRSZ] = "";
    while(1){
        // receive message from client

        fprintf(stdout, "Client: %s\n", msg);
        
        // if message is END break out
        fprintf(stdout, "Server: ");
        fscanf(stdin, "%[^\n]s", msg); // read input with space until a newline
        setbuf(stdin, NULL); // clear stdin buffer

        // Send message to client
    }
    // close connection and listening socket
    
    fprintf(stdout, "Server exiting...\n");
    return 0;

}