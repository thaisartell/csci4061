#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>

#define BACKLOG 5 // connection request queue of 5
#define STRSZ 100
#define PORT 3000 
#define MAXCLIENTS 10

struct MessageStruct {
    int id;
    char msg[STRSZ];
};

typedef struct MessageStruct message;

/****************************/
// IMPORTANT: ERROR CHECK ALL SOCKET APIs
/****************************/

void *clientHandler(void *args) {
    int connfd = *((int *)args);

    // receive message from client

    // close connection socket

    return NULL;

}
int main(int argc, char *argv[]) {
    // create listening TCP socket
    int listen_fd;

    // Forcefully attaching socket to the port
    // In your PA2-phase2, for each testcase, the server has to be stopped using Ctrl+C. You might get connection refused/bad binding the next time you run server
    // This occurs due to the abrupt interruption of the server in the previous run. To avoid this, use the following API. (samples/eg2)


    // create sockaddr_in for server with listening port and address informatin
    struct sockaddr_in servaddr;

    // bind the listen_fd to servaddr

    // set the listening queue for server with backlog BACKLOG
    
    int conn_fd[MAXCLIENTS]; // connection sockets
    int conn_fd_iter = 0;

    pthread_t thds[MAXCLIENTS];
    while(1){
        // accept connection request from client and create new socket
        
        // create thread per connection that executes clientHandler
        
        // detach the thread
        
    }

    // The following set of lines will never be executed.
    close(listen_fd);
    fprintf(stdout, "Server exiting...\n");
    return 0;

}