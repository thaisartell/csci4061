#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <stdlib.h>

#define STRSZ 100
#define PORT 3000

struct MessageStruct {
    int id;
    char msg[STRSZ];
};

typedef struct MessageStruct message;

/****************************/
// IMPORTANT: ERROR CHECK ALL SOCKET APIs
/****************************/

int main(int argc, char *argv[]) {
    // pass one argument to client
    if(argc != 2){
        printf("ERROR: Usage: ./client <clientid>");
        exit(EXIT_FAILURE);
    }
    int id = atoi(argv[1]); // client id

    // create TCP socket
    int sockfd;

    // create sockaddr with server information
    struct sockaddr_in servaddr;

    // connect to server using sockfd

    message cmsg;
    memset(&cmsg, 0, sizeof(cmsg));
    cmsg.id = id;
    fprintf(stdout, "Client: ");
    fscanf(stdin, "%[^\n]s", cmsg.msg); // read input with space until a newline
    setbuf(stdin, NULL); // clear stdin buffer

    // send message to server

    // close sockfd
    close(sockfd);

    fprintf(stdout, "Client exiting...\n");

    return 0;
}